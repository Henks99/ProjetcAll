"""Do math with your own functions.

Modules exported by this package:

- `calculations`: Provide several sample math calculations.
"""
